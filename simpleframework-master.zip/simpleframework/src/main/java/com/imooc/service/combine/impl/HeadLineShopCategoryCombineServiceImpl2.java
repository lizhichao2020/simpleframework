package com.imooc.service.combine.impl;

import com.imooc.entity.dto.MainPageInfoDTO;
import com.imooc.entity.dto.Result;
import com.imooc.service.combine.HeadLineShopCategoryCombineService;
import org.simpleframework.core.annotation.Service;

@Service
public class HeadLineShopCategoryCombineServiceImpl2 implements HeadLineShopCategoryCombineService {
    @Override
    public Result<MainPageInfoDTO> getMainPageInfo() {
        return null;
    }
}
