package demo.api.assignable;

public interface ThirdInterface extends SecondInterface {
}
