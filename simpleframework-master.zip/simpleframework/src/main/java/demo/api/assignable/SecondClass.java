package demo.api.assignable;

public class SecondClass extends FirstClass {
}
