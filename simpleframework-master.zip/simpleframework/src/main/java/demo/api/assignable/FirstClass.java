package demo.api.assignable;

public class FirstClass {
}
