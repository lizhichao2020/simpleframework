package demo.api.assignable;

public interface UnrelevantInterface {
}
