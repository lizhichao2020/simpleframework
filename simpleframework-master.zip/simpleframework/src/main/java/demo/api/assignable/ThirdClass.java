package demo.api.assignable;

public class ThirdClass extends SecondClass implements ThirdInterface {
}
