package demo.api.assignable;

public interface SecondInterface extends FirstInterface {
}
