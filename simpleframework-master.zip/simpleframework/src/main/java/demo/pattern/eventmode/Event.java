package demo.pattern.eventmode;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class Event {
    private String type;
}
