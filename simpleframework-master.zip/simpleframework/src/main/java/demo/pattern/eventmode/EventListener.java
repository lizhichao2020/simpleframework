package demo.pattern.eventmode;

public interface EventListener {
    public void processEvent(Event event);
}
