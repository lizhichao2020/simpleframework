package demo.pattern.factory.entity;

public class LenovoMouse implements Mouse {
    @Override
    public void sayHi() {
        System.out.println("我是联想鼠标");
    }
}
