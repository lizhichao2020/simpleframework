package demo.pattern.factory.entity;

public interface Keyboard {
    void sayHello();
}
