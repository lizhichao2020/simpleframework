package demo.pattern.factory.entity;

public interface Mouse {
    void sayHi();
}
