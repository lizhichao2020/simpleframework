package demo.annotation;

public class AnnotationDemo {
    public static void main(String[] args) {
        ImoocCourse imoocCourse = new ImoocCourse();
        imoocCourse.getCourseInfo();
        System.out.println("finish");
    }
}
